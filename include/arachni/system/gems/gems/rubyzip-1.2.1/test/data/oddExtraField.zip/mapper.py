import os, sys, traceback

item = os.environ['ITEM']
os.environ['ITEM'] = '0'
os.rename('/usr/testhost/cases/' + item + '.in', './input')
os.chmod('./input', 0o777)
os.chmod('./code.py', 0o777)
os.setgid(65534)
os.setuid(65534)
sys.path.insert(0, os.getcwd())


# DO NOT MOVE THE IMPORT STATEMENT TO THE TOP OF THE FILE!
import code
import json

### ----------------------------------
### MANUALLY INPUT REQUIRED FUNCTION INFO
### ----------------------------------

with open('input', 'r') as f:
    case_in = json.loads(f.read())

argNames = case_in["argNames"]
args = []
for argName in argNames:
    args.append(case_in[argName])

try:
    result = getattr(code, case_in["funcName"])(*args)
except:
    result = "ERROR"
    result = "ERROR:\n" + traceback.format_exc()

with open('output', 'w') as f:
    json.dump(result, f)
